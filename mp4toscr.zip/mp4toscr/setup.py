from setuptools import setup, find_packages

setup(
    name='mp4_to_scr',
    version='1.0.0',
    packages=find_packages(),
    install_requires=[
        # Add any dependencies here, e.g., if you use other libraries
    ],
    author='Marcin Jacek Chmiel',
    author_email='martingonn.dev@outlook.com',
    description='A library to convert MP4 to SCR format.',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url='https://github.com/Martingonn/mp4_to_scr',  # Optional
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: Apache 2.0 License',  # Change as needed
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',  # Change as needed
)
