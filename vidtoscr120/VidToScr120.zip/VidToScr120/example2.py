import subprocess
import os

def convert_scr_to_mp4(input_file, output_file, ffmpeg_path="ffmpeg"):
    """
    Converts an SCR file to MP4 using FFmpeg.

    Parameters:
    - input_file: Path to the SCR file.
    - output_file: Desired path for the MP4 output.
    - ffmpeg_path: Path to the FFmpeg executable.
    """
    if not os.path.exists(input_file):
        print(f"Error: Input file '{input_file}' does not exist.")
        return

    command = [
        ffmpeg_path,
        "-i", input_file,
        "-c:v", "libx264",
        "-crf", "23",
        output_file
    ]

    try:
        subprocess.run(command, check=True)
        print(f"Conversion successful: '{input_file}' -> '{output_file}'")
    except subprocess.CalledProcessError as e:
        print(f"Conversion failed with error: {e}")

def convert_mp4_to_scr(input_file, output_file, ffmpeg_path="ffmpeg"):
    """
    Converts an MP4 file to SCR using FFmpeg.

    Parameters:
    - input_file: Path to the MP4 file.
    - output_file: Desired path for the SCR output.
    - ffmpeg_path: Path to the FFmpeg executable.
    """
    if not os.path.exists(input_file):
        print(f"Error: Input file '{input_file}' does not exist.")
        return

    command = [
        ffmpeg_path,
        "-i", input_file,
        "-c:v", "libx264",
        "-crf", "23",
        output_file
    ]

    try:
        subprocess.run(command, check=True)
        print(f"Conversion successful: '{input_file}' -> '{output_file}'")
    except subprocess.CalledProcessError as e:
        print(f"Conversion failed with error: {e}")

def main_menu():
    """
    Displays a menu for the user to choose between SCR-to-MP4 and MP4-to-SCR conversion.
    """
    while True:
        print("\n=== Conversion Menu ===")
        print("1) Convert .scr to .mp4")
        print("2) Convert .mp4 to .scr")
        print("3) Exit")

        choice = input("Choose an option (1/2/3): ").strip()

        if choice == "1":
            input_scr = input("Enter the path to the .scr file: ").strip()
            output_mp4 = input("Enter the desired path for the .mp4 file: ").strip()
            ffmpeg_path = input("Enter the path to FFmpeg (default is 'ffmpeg'): ").strip() or "ffmpeg"
            convert_scr_to_mp4(input_scr, output_mp4, ffmpeg_path)
        
        elif choice == "2":
            input_mp4 = input("Enter the path to the .mp4 file: ").strip()
            output_scr = input("Enter the desired path for the .scr file: ").strip()
            ffmpeg_path = input("Enter the path to FFmpeg (default is 'ffmpeg'): ").strip() or "ffmpeg"
            convert_mp4_to_scr(input_mp4, output_scr, ffmpeg_path)

        elif choice == "3":
            print("Exiting program.")
            break
        
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main_menu()
