from vidtoscr import Mp4ToScrConverter, record_screen_saver, convert_scr_to_mp4

def main():
    # Example usage for MP4 to SCR conversion
    input_mp4 = input("Enter the path to the MP4 file: ")
    output_scr = input("Enter the desired path for the SCR file: ")
    ffmpeg_path = input("Enter the path to FFmpeg (default is 'ffmpeg'): ") or "ffmpeg"
    
    converter = Mp4ToScrConverter(ffmpeg_path=ffmpeg_path)
    try:
        converter.convert_to_scr(input_mp4, output_scr)
    except Exception as e:
        print(f"Error: {e}")
    
    # Example usage for SCR to MP4 conversion
    input_scr = input("Enter the path to the SCR file: ")
    output_mp4 = input("Enter the desired path for the MP4 file: ")
    
    convert_scr_to_mp4(input_scr, output_mp4, ffmpeg_path=ffmpeg_path)

if __name__ == "__main__":
    main()
