import os
import subprocess
from VidToScr import Mp4ToScrConverter  # Correct import

def main():
    # Example 1: Basic conversion with default FFmpeg path
    print("\n=== Example 1: Basic Conversion ===")
    converter = Mp4ToScrConverter()  # Use the class, not the module
    input_mp4 = "test_video.mp4"
    output_scr = "basic_output.scr"
    
    try:
        converter.convert_to_scr(input_mp4, output_scr)
    except FileNotFoundError as e:
        print(f"Error: {e}")
    except RuntimeError as e:
        print(f"FFmpeg Error: {e}")

    # Example 2: Custom FFmpeg path
    print("\n=== Example 2: Custom FFmpeg Path ===")
    custom_ffmpeg_path = "ffmpeg"  # Replace with your actual path
    converter_custom = Mp4ToScrConverter(ffmpeg_path=custom_ffmpeg_path)
    input_mp4 = "test_video.mp4"
    output_scr = "custom_ffmpeg_output.scr"
    
    try:
        converter_custom.convert_to_scr(input_mp4, output_scr)
    except FileNotFoundError as e:
        print(f"Error: {e}")
    except RuntimeError as e:
        print(f"FFmpeg Error: {e}")

    # Example 3: Invalid input file
    print("\n=== Example 3: Invalid Input File ===")
    invalid_input = "non_existent_file.mp4"
    output_scr = "invalid_output.scr"
    
    try:
        converter.convert_to_scr(invalid_input, output_scr)
    except FileNotFoundError as e:
        print(f"Error: {e}")

    # Example 4: FFmpeg failure simulation
    print("\n=== Example 4: FFmpeg Failure Simulation ===")
    converter_invalid = Mp4ToScrConverter(ffmpeg_path="non_existent_command")
    input_mp4 = "test_video.mp4"
    output_scr = "invalid_ffmpeg_output.scr"
    
    try:
        converter_invalid.convert_to_scr(input_mp4, output_scr)
    except RuntimeError as e:
        print(f"FFmpeg Error: {e}")

if __name__ == "__main__":
    main()
