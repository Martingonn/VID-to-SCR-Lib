import os
from VidToScr import Mp4ToScrConverter

def main():
    # Example 1: Basic Conversion
    print("\n=== Example 1: Basic Conversion ===")
    input_mp4 = input("Input file path to .mp4: ")
    output_scr = input("Output file path for .scr: ")  # User must include filename
    
    # Validate paths
    if not os.path.exists(input_mp4):
        print(f"Error: Input file '{input_mp4}' does not exist.")
        return
    
    # Ensure output directory exists
    output_dir = os.path.dirname(output_scr)
    if not os.path.exists(output_dir):
        print(f"Error: Output directory '{output_dir}' does not exist.")
        return
    
    converter = Mp4ToScrConverter(ffmpeg_path="C:/ffmpeg/bin/ffmpeg.exe") #change to your file path
    try:
        converter.convert_to_scr(input_mp4, output_scr)
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()
